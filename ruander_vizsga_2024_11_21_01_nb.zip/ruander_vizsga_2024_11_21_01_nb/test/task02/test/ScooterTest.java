package task02.test;

import org.junit.Assert;
import org.junit.Test;
import task02.app.ElectricScooter;
import task02.app.Scooter;

public class ScooterTest {

    @Test
    public void isOldTest() {
        Scooter scooter = new Scooter("BestScooterFor4U", 2020, "fehér",
                "TRE-4456");
        Boolean actual = scooter.isOld();
        Boolean expected = false;
        Assert.assertEquals(expected, actual);
    }
    
    @Test
    public void canUseInTrafficCaseFalse(){
        ElectricScooter eScooter = new ElectricScooter(15000, 30, "TesztMarka", 2000, "fehér", "001");
        Boolean actual = eScooter.canUseInTraffic();
        Boolean expected = false;
        Assert.assertEquals(expected, actual);
    }
    
    @Test
    public void canUseInTrafficCaseTrue(){
        ElectricScooter eScooter = new ElectricScooter(15000, 20, "TesztMarka", 2000, "fehér", "002");
        Boolean actual = eScooter.canUseInTraffic();
        Boolean expected = true;
        Assert.assertEquals(expected, actual);
    }
}
