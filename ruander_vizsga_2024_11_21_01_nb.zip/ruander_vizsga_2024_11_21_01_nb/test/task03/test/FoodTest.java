package task03.test;

import java.util.HashMap;
import java.util.Map;
import org.junit.Assert;
import org.junit.Test;
import task03.app.Food;
import task03.app.Order;
import task03.app.OrderItem;

public class FoodTest {

    @Test
    public void getDiscountedPriceTest() {
        Food food = new Food("Tonhalas Pizza", 5000.0, true);
        double actual = food.getDiscountedPrice();
        double expected = 4500.0;
        Assert.assertEquals(expected, actual, 0.0);
    }
    
    @Test
    public void getDiscountedPriceTestFalse() {
        Food food = new Food("Tonhalas Pizza", 5000.0, false);
        double actual = food.getDiscountedPrice();
        double expected = 5000;
        Assert.assertEquals(expected, actual, 0.0);
    }
    
    @Test
    public void calculateTotalPriceTest(){
        Food bolognese = new Food("rakott krumpli", 5000.0, false);
        Food hawaii = new Food("csülkös bab", 5000.0, false);
        OrderItem itemOne = new OrderItem(bolognese, 2);
        OrderItem itemTwo = new OrderItem(hawaii, 1);
        Map<Integer, OrderItem> orderMap = new HashMap();
        orderMap.put(1, itemOne);
        orderMap.put(2, itemTwo);
        Order order = new Order((long) 1, orderMap);
        double actual = order.getTotalCost();
        double expected = 15000.0;
        Assert.assertEquals(expected, actual, 0.0);
        
    }
}
