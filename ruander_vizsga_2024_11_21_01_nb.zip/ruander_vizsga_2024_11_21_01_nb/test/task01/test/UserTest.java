package task01.test;

import java.time.LocalDate;
import org.junit.Assert;
import org.junit.Test;
import task01.app.User;

public class UserTest {

    @Test
    public void testUserStatusText() {
        User user = new User("Elek", "Teszt", "tesztelek", LocalDate.
                of(1999, 01, 01), true);
        String actual = user.getStatusText();
        String expected = "aktív";
        Assert.assertEquals(expected, actual);
    }
    
    @Test
    public void testUserStatusTextFalse() {
        User user = new User("Elek", "Teszt", "tesztelek", LocalDate.
                of(1999, 01, 01), false);
        String actual = user.getStatusText();
        String expected = "inaktív";
        Assert.assertEquals(expected, actual);
    }
    
    @Test
    public void testUserAge(){
        User user = new User("Elek", "Teszt", "tesztelek", LocalDate.
                of(1999, 01, 01), false);
        int actual = user.calculateAge();
        int expected = 25;
        Assert.assertEquals(expected, actual);
    }
}
