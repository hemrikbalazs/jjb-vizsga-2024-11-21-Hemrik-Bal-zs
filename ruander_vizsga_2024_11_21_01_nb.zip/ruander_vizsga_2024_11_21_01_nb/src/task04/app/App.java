package task04.app;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class App {

    public static void main(String[] args) {
        List<FootWear> shoeList = new ArrayList();

        try {
            FileReader reader = new FileReader("fit_shoes.csv");
            BufferedReader bReader = new BufferedReader(reader);
            String line = bReader.readLine();
            FootWear shoe = createShoe(line);
            shoeList.add(shoe);
            bReader.close();
            reader.close();

        } catch (FileNotFoundException ex) {
            Logger.getLogger(App.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(App.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private static FootWear createShoe(String line) {
        String[] data = line.split(";");
        int size = Integer.parseInt(data[0]);
        String brand = data[1];
        String model = data[2];
        Double netPrice = Double.parseDouble(data[3]);
        Byte category = Byte.parseByte(data[4]);
        Boolean sale = digitStringToBoolean(data[5]);
        return new FootWear(size, brand, model, netPrice, category, sale);
    }

    private static Boolean digitStringToBoolean(String string) {
        return string == "1";
    }
}
