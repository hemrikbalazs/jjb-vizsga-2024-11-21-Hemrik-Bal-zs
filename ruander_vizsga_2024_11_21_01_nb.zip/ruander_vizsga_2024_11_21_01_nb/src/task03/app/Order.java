package task03.app;

import java.util.Map;

public class Order {

	private Long id;
	private Map<Integer, OrderItem> orderItems;
	
	public Order(Long id, Map<Integer, OrderItem> map) {
		this.id = id;
		this.orderItems = map;
	}
	
	public Map<Integer, OrderItem> getOrderItems() {
		return orderItems;
	}
	
	public Long getId() {
		return id;
	}
        
        public double getTotalCost(){
            OrderItem tempItem;
            double tempPrice;
            double result = 0;
            for (int i = 0; i < orderItems.size(); i++) {
                tempItem = orderItems.get(i + 1);
                tempPrice = calculateTempPrice(tempItem);
                result += tempPrice;
            }
            return result;
        }

    private double calculateTempPrice(OrderItem orderItem) {
        int quantity = orderItem.getQuantity();
        Food food = orderItem.getFood();
        return quantity * food.getDiscountedPrice();
    }
}
