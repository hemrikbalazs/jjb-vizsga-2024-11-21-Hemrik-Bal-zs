package task03.app;

import java.util.HashMap;
import java.util.Map;

public class App {

    public static void main(String[] args) {
        Food bolognese = new Food("Pizza bolognese", 3900.0, false);
        Food hawaii = new Food("Hawaii pizza", 4500.0, true);
        OrderItem itemOne = new OrderItem(bolognese, 2);
        OrderItem itemTwo = new OrderItem(hawaii, 1);
        Map<Integer, OrderItem> orderMap = new HashMap();
        orderMap.put(1, itemOne);
        orderMap.put(2, itemTwo);
        Order order = new Order((long) 1, orderMap);
        System.out.println("A rendelés azonosítója: " + order.getId() + ", teljes összeg: " + order.getTotalCost());
    }
}
