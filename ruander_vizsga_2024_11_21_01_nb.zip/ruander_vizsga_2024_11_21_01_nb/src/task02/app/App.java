package task02.app;

public class App {

	public static void main(String[] args) {
            ElectricScooter scotty = new ElectricScooter(10000, 25, "BestElectricRoller4U", 2022, "fekete", "M-531");
            System.out.println(scotty.canUseInTraffic());
        }
}
