package task02.app;

/**
 *
 * @author Vizsga
 */
public class ElectricScooter extends Scooter {
    
    private int batteryCapacity;
    private int maxSpeed;

    public ElectricScooter(int batteryCapacity, int maxSpeed, String brand, int yearManufactured, String color, String model) {
        super(brand, yearManufactured, color, model);
        this.batteryCapacity = batteryCapacity;
        this.maxSpeed = maxSpeed;
    }
    
    public boolean canUseInTraffic(){
        return maxSpeed <= 25;
    }
    
}
