package task01.app;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class App {

	public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Adja meg a keresztnevét: ");
            String firstName = scanner.nextLine();
            System.out.println("Adja meg a vezetéknevét: ");
            String lastName = scanner.nextLine();
            System.out.println("Adja meg a felhasználónevét: ");
            String userName = scanner.nextLine();
            System.out.println("Adja meg a születési dátumát YYYY-MM-DD formátumban: ");
            String birthDateString = scanner.nextLine();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate birthDate = LocalDate.parse(birthDateString, formatter);
            User user = new User(firstName, lastName, userName, birthDate, true);
            int age = user.calculateAge();
            System.out.println("Teljes neve: " + user.getLastName() + " " + user.getFirstName());
            System.out.println("Felhasználóneve: " + user.getUserName());
            System.out.println("Életkora: " + age);
	}

}
