package task01.app;

import java.time.LocalDate;

public class User {

    private String firstName;
    private String lastName;
    private String userName;
    private LocalDate dateOfBirth;
    private Boolean status;

    public User(String firstName, String lastName, String userName, LocalDate dateOfBirth, Boolean status) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
        this.dateOfBirth = dateOfBirth;
        this.status = status;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getUserName() {
        return userName;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public Boolean getStatus() {
        return status;
    }

    public String getStatusText() {
        return status ? "aktív" : "inaktív";
    }

    public int calculateAge() {
        LocalDate now = LocalDate.now();
        LocalDate birthDay = LocalDate.of(now.getYear(), dateOfBirth.getMonth(), dateOfBirth.getDayOfMonth());
        int result = now.getYear() - dateOfBirth.getYear();
        if (birthDay.isAfter(now)) {
            result = result - 1;
        }
        return result;
    }

        @Override
        public String toString() {
		return "User [firstName=" + firstName + ", lastName=" + lastName + ", userName=" + userName + ", dateOfBirth="
                    + dateOfBirth + "]";
        }
    }
